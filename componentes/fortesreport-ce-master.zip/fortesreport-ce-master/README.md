<!-- # - logo -->
[<img src="https://www.fortestecnologia.com.br/wp-content/themes/atratis/images/logo-fortes-tecnologia.gif" alt="drawing" width="500"/>](https://www.fortestecnologia.com.br/)

<!-- # - about -->
# FortesReport Community Edition
The FortesReport is a powerful report generator available as a package of components for Delphi. In FortesReport, the reports are composed of bands that have specific functions in the print stream. You define groupings, sublevels and totals simply by hierarchical relationship between bands. Moreover, the FortesReport has a rich palette of components for text, charts, formulas, bar codes, filters and layout.

<!-- # - lang -->
#
[<img src="https://raw.githubusercontent.com/hampusborgos/country-flags/main/svg/gb.svg" alt="drawing" height="26"/>](https://github.com/fortesinformatica/fortesreport-ce/blob/master/README.md)
[<img src="https://raw.githubusercontent.com/hampusborgos/country-flags/main/svg/br.svg" alt="drawing" height="26"/>](https://github.com/fortesinformatica/fortesreport-ce/blob/master/README.pt-BR.md)
